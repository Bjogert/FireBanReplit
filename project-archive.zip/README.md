Getting Started: 

Dependencies:

Install npm, Vite, and Node.js for your operating system according to the instructions at:

https://nodejs.org/en/download/package-manager

How to Start the App:
Run the following command in the FireBanReplit repository:

npm run dev
When you see the following output:

VITE v5.3.1 ready in 497 ms

➜  Local:   http://localhost:5173/FireBanReplit/
➜  Network: use --host to expose
➜  Press 'H' + 'Enter' to show help
Ctrl-click or copy the local HTTP link to your browser and you will be directed to the FireBanreplit site.